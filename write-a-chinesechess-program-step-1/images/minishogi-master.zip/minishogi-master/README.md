# minishogi
An HTML5 Canvas minishogi (shogi played on a 5x5 board) client written in pure JavaScript.